<?php
    require('connectDB.php');
    header('Access-Control-Allow-Origin: *');

$query = "SELECT ID_reserve,TypeOrder,ID_user,CheckOrdMenu,Date, TIME_FORMAT(Time, '%H:%i') as Time, Count_guest,Name,LastName,Telephone,Notes,DATE_FORMAT(Data_create, '%Y-%m-%d %H:%i') as Data_create, Status, IF(UseBonus = 1, true, false) as UseBonus, Bonus, TokenMessage FROM Reserve_table ORDER BY Reserve_table.ID_reserve DESC";
$result = $pdo->query($query);
$result2 = $result->fetchAll(PDO::FETCH_ASSOC);
$newArray = array();
//print_r($result2);

foreach($result2 as $arr){
   $newArray[] = array("ID_reserve" => $arr['ID_reserve'],"TypeOrder" => $arr['TypeOrder'],"ID_user" => $arr['ID_user'],"CheckOrdMenu" => $arr['CheckOrdMenu'],"Date" => $arr['Date'],"Time" => $arr['Time'],"Count_guest" => $arr['Count_guest'],"Name" => $arr['Name'],"LastName" => $arr['LastName'],"Telephone" => $arr['Telephone'],"Notes" => $arr['Notes'],"Data_create" => $arr['Data_create'],"Status" => $arr['Status'],"UseBonus" => $arr['UseBonus'],"Bonus" => $arr['Bonus'],"TokenMessage" => $arr['TokenMessage']);
    
    
}
//var_dump($newArray);
//$string = implode(" ", $newArray);
//echo json_encode($string);
//echo json_encode($newArray);
echo json_encode($newArray, JSON_NUMERIC_CHECK);

  //  foreach ($result as $row){
    //    if( ($row["TypeOrder"] == "mobile") && ($row["CheckOrdMenu"] == '1') ){
      //      $query = $pdo->prepare('SELECT Title_dish,Caption_dish,Price_dish,Amount_dish FROM Menu_table LEFT JOIN ReserveMenu_table ON Menu_table.ID_dish = ReserveMenu_table.ID_dish WHERE ReserveMenu_table.ID_reserve = :id_reserve');
        //    $query->execute(array('id_reserve' => $row["ID_reserve"]));
          //  $row["dishes"] = $query->fetchAll();
       // }
        //$data[] = $row;
  //  }
   // echo json_encode($data);
    //echo $data;

//echo '[{"ID_reserve":6,"TypeOrder":"mobile","ID_user":14,"CheckOrdMenu":0,"Date":"2017-06-16","TimeCount_guest":"13:00","Name":"\u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440","LastName":"\u041c\u0430\u0437\u0430\u043b\u043e\u0432","Telephone":"+375296947131","Notes":"","Data_create":"2017-06-11 23:41","Status":"new","UseBonus":0,"Bonus":0,"TokenMessage":""},{"ID_reserve":3,"TypeOrder":"site","ID_user":null,"CheckOrdMenu":0,"Date":"2017-06-13","TimeCount_guest":"14:00","Name":"GSdffs","LastName":"Fdfsf","Telephone":"+375296947131","Notes":"dgfhdgh","Data_create":"2017-06-11 22:40","Status":"accept","UseBonus":0,"Bonus":0,"TokenMessage":null}]';


?>     

